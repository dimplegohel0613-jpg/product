"use client";

import { useRef, useMemo } from "react";
import type { Group } from "three";
import { useFrame, useThree } from "@react-three/fiber";
import ModelCard from "./ModelCard";

const ITEMS = [
  { src: "/models/mqc5g7trsbvu99.png", title: "Elegant Summer Dress" },
  { src: "/models/mqc5grbcf2t65q.png", title: "Modern Kurti Collection" },
  { src: "/models/mqc5iow8j0jxj6.png", title: "Luxury Saree Showcase" },
  { src: "/models/mqc5j3yoq6yuw7.png", title: "Men's Casual Fashion" },
  { src: "/models/mqc5jvfl9v9d9x.png", title: "Men's Formal Wear" },
  { src: "/models/mqc5l2jlx3edzj.png", title: "Girls Fashion Collection" },
  { src: "/models/mqc5m3s45o5l43.png", title: "Boys Fashion Collection" },
  { src: "/models/mqc5mu8piyzc6y.png", title: "Family Clothing Brand" },
];

const COUNT = ITEMS.length;
const RADIUS = 3.5;

export default function Carousel({ scrollProgress = 0 }: { scrollProgress?: number }) {
  const groupRef = useRef<Group>(null);
  const { pointer } = useThree();

  useFrame(() => {
    if (!groupRef.current) return;
    const scrollRot = scrollProgress * Math.PI * 2;
    const mouseRot = pointer.x * 0.3;
    groupRef.current.rotation.y = scrollRot + mouseRot;
  });

  const cards = useMemo(
    () =>
      ITEMS.map((item, i) => {
        const angle = (i / COUNT) * Math.PI * 2;
        const x = Math.sin(angle) * RADIUS;
        const z = Math.cos(angle) * RADIUS;
        return (
          <group key={item.src} position={[x, 0, z]}>
            <ModelCard imagePath={item.src} title={item.title} />
          </group>
        );
      }),
    []
  );

  return (
    <group ref={groupRef} position={[0, 0, 0]}>
      {cards}
    </group>
  );
}
