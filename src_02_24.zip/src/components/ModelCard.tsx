"use client";

import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import type { Group } from "three";
import { useTexture, Text } from "@react-three/drei";

interface ModelCardProps {
  imagePath: string;
  title: string;
}

export default function ModelCard({ imagePath, title }: ModelCardProps) {
  const groupRef = useRef<Group>(null);
  const texture = useTexture(imagePath);
  const { camera } = useThree();

  useFrame(() => {
    if (!groupRef.current) return;
    groupRef.current.lookAt(camera.position);
  });

  return (
    <group ref={groupRef}>
      <mesh>
        <planeGeometry args={[1.5, 2.25]} />
        <meshBasicMaterial map={texture} transparent side={2} />
      </mesh>

      <group position={[0, -1.22, 0]}>
        <mesh>
          <planeGeometry args={[1.2, 0.26]} />
          <meshBasicMaterial color="#222" />
        </mesh>
        <Text
          position={[0, 0, 0.02]}
          fontSize={0.09}
          color="#c8a46d"
          anchorX="center"
          anchorY="middle"
          maxWidth={1.1}
          textAlign="center"
        >
          {title}
        </Text>
      </group>
    </group>
  );
}
