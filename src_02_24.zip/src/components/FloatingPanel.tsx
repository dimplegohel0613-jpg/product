"use client";

import { useRef } from "react";
import { motion } from "framer-motion";

interface FloatingPanelProps {
  subtitle: string;
  title: string;
  description: string;
  index: number;
  align?: "left" | "right";
}

export default function FloatingPanel({
  subtitle,
  title,
  description,
  index,
  align = "left",
}: FloatingPanelProps) {
  const panelRef = useRef<HTMLDivElement>(null);

  return (
    <motion.div
      ref={panelRef}
      initial={{ opacity: 0, y: 50, x: align === "left" ? -30 : 30 }}
      whileInView={{ opacity: 1, y: 0, x: 0 }}
      viewport={{ once: false, amount: 0.3 }}
      transition={{ duration: 0.9, ease: [0.25, 0.1, 0.25, 1], delay: index * 0.15 }}
      className={`backdrop-blur-xl bg-white/30 border border-white/40 rounded-sm p-8 md:p-10 max-w-sm ${align === "right" ? "ml-auto" : ""}`}
    >
      <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">
        {subtitle}
      </span>
      <h2 className="font-serif text-3xl md:text-4xl text-charcoal leading-tight mt-2 mb-4">
        {title}
      </h2>
      <div className="w-12 h-px bg-gold mb-4" />
      <p className="text-charcoal-light text-sm leading-relaxed font-light tracking-wide">
        {description}
      </p>
    </motion.div>
  );
}
