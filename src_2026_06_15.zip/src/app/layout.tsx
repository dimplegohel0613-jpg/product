import type { Metadata } from "next";
import "./globals.css";
import MagneticCursor from "@/components/MagneticCursor";

export const metadata: Metadata = {
  title: "Dimple | Premium Fashion",
  description: "Premium fashion landing experience",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="h-full">
      <body className="min-h-full">
        <MagneticCursor />
        {children}
      </body>
    </html>
  );
}
