"use client";

import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import type { Group, Mesh } from "three";
import * as THREE from "three";
import { useTexture, Text } from "@react-three/drei";

interface ModelCardProps {
  imagePath: string;
  title: string;
  index: number;
  isActive: boolean;
}

export default function ModelCard({ imagePath, title, index, isActive }: ModelCardProps) {
  const groupRef = useRef<Group>(null);
  const glowRef = useRef<Mesh>(null);
  const texture = useTexture(imagePath);
  const { camera, pointer } = useThree();
  const timeRef = useRef(0);
  const lookTarget = useRef(new THREE.Vector3());

  useFrame((_, delta) => {
    if (!groupRef.current) return;

    lookTarget.current.set(
      camera.position.x + pointer.x * 0.4,
      camera.position.y + pointer.y * 0.3,
      camera.position.z
    );
    groupRef.current.lookAt(lookTarget.current);

    timeRef.current += delta;

    if (glowRef.current) {
      const targetOpacity = isActive ? 0.4 : 0;
      glowRef.current.material.opacity += (targetOpacity - glowRef.current.material.opacity) * 0.08;
    }

    const floatY = Math.sin(timeRef.current * 0.8 + index * 0.9) * 0.08;
    groupRef.current.position.y = floatY;

    const targetScale = isActive ? 1.12 : 1;
    const currentScale = groupRef.current.scale.x;
    const newScale = currentScale + (targetScale - currentScale) * 0.08;
    groupRef.current.scale.setScalar(newScale);
  });

  return (
    <group ref={groupRef}>
      <mesh ref={glowRef} position={[0, 0, -0.01]} scale={[1.12, 1.1, 1]}>
        <planeGeometry args={[1.5, 2.25]} />
        <meshBasicMaterial
          color="#c8a46d"
          transparent
          opacity={0}
          depthWrite={false}
        />
      </mesh>

      <mesh>
        <planeGeometry args={[1.5, 2.25]} />
        <meshBasicMaterial map={texture} transparent side={2} />
      </mesh>

      <group position={[0, -1.22, 0]}>
        <mesh>
          <planeGeometry args={[1.2, 0.26]} />
          <meshBasicMaterial color="#222" />
        </mesh>
        <Text
          position={[0, 0, 0.02]}
          fontSize={0.09}
          color="#c8a46d"
          anchorX="center"
          anchorY="middle"
          maxWidth={1.1}
          textAlign="center"
        >
          {title}
        </Text>
      </group>
    </group>
  );
}
