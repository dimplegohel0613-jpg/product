"use client";

import { Canvas } from "@react-three/fiber";
import Carousel from "./Carousel";
import Particles from "./Particles";

export default function Scene({ scrollProgress = 0 }: { scrollProgress?: number }) {
  return (
    <div className="fixed top-0 left-0 w-screen h-screen -z-10">
      <Canvas
       camera={{ position: [0, 0.2, 9], fov: 45, near: 0.1, far: 100 }}
        dpr={[1, 1.5]}
        gl={{ antialias: true, alpha: true }}
        style={{ width: "100vw", height: "100vh" }}
      >
        <ambientLight intensity={1.5} />
        <directionalLight position={[5, 8, 6]} intensity={2} />
        <directionalLight position={[-3, 4, -2]} intensity={0.6} />
        <pointLight position={[0, 3, 2]} intensity={0.4} color="#c8a46d" />
        <Carousel scrollProgress={scrollProgress} />
        <Particles />
      </Canvas>
    </div>
  );
}
