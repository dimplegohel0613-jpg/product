"use client";

import { useRef, useMemo } from "react";
import type { Group } from "three";
import { useFrame, useThree } from "@react-three/fiber";
import ModelCard from "./ModelCard";

const ITEMS = [
  "/models/mqc5g7trsbvu99.png",
  "/models/mqc5grbcf2t65q.png",
  "/models/mqc5iow8j0jxj6.png",
  "/models/mqc5j3yoq6yuw7.png",
  "/models/mqc5jvfl9v9d9x.png",
  "/models/mqc5l2jlx3edzj.png",
  "/models/mqc5m3s45o5l43.png",
  "/models/mqc5mu8piyzc6y.png",
];

const COUNT = ITEMS.length;
const RADIUS = 2.5;

export default function Carousel({ scrollProgress = 0 }: { scrollProgress?: number }) {
  const groupRef = useRef<Group>(null);
  const { pointer } = useThree();

  useFrame(() => {
    if (!groupRef.current) return;
    const scrollRot = scrollProgress * Math.PI * 2;
    const mouseRot = pointer.x * 0.2;
    const mouseTilt = pointer.y * 0.05;
    groupRef.current.rotation.y = scrollRot + mouseRot;
    groupRef.current.rotation.x = mouseTilt;
  });

  const cards = useMemo(
    () =>
      ITEMS.map((src, i) => {
        const angle = (i / COUNT) * Math.PI * 2;
        const x = Math.sin(angle) * RADIUS;
        const z = Math.cos(angle) * RADIUS;
        return (
          <group key={src} position={[x, 0, z]}>
            <ModelCard imagePath={src} />
          </group>
        );
      }),
    []
  );

  return (
    <group ref={groupRef} position={[0, 0.2, 0]}>
      {cards}
    </group>
  );
}
