"use client";

import { useRef } from "react";
import { useFrame, useThree } from "@react-three/fiber";
import type { Mesh } from "three";
import { useTexture } from "@react-three/drei";

interface ModelCardProps {
  imagePath: string;
}

export default function ModelCard({ imagePath }: ModelCardProps) {
  const meshRef = useRef<Mesh>(null);
  const texture = useTexture(imagePath);
  const { camera } = useThree();

  useFrame(() => {
    if (!meshRef.current) return;
    meshRef.current.lookAt(camera.position);
  });

  return (
    <mesh ref={meshRef}>
      <planeGeometry args={[1.5, 2.25]} />
      <meshBasicMaterial map={texture} transparent side={2} />
    </mesh>
  );
}
