"use client";

import { useState, useCallback } from "react";
import Scene from "@/components/Scene";
import SmoothScroll from "@/components/SmoothScroll";

const LABELS = [
  { num: "01", title: "Look One" },
  { num: "02", title: "Look Two" },
  { num: "03", title: "Look Three" },
  { num: "04", title: "Look Four" },
  { num: "05", title: "Look Five" },
  { num: "06", title: "Look Six" },
  { num: "07", title: "Look Seven" },
  { num: "08", title: "Look Eight" },
];

const totalSlides = LABELS.length;
const visibleCount = 3;

export default function Home() {
  const [scrollProgress, setScrollProgress] = useState(0);

  const handleScroll = useCallback((progress: number) => {
    setScrollProgress(progress);
  }, []);

  const activeIndex = Math.round(scrollProgress * (totalSlides - visibleCount));

  return (
    <SmoothScroll onScroll={handleScroll}>
      <Scene scrollProgress={scrollProgress} />

      <main className="relative z-10">
        <div className="fixed right-8 md:right-16 lg:right-24 top-1/2 -translate-y-1/2 pointer-events-none">
          {LABELS.map((label, i) => (
            <div
              key={label.num}
              className="transition-all duration-700 ease-out"
              style={{
                opacity: i === activeIndex ? 1 : 0,
                transform: `translateY(${(i - activeIndex) * 10}px)`,
                position: "absolute",
                top: 0,
                right: 0,
              }}
            >
              <span className="text-gold text-xs tracking-[0.3em] uppercase font-medium">
                {label.num}
              </span>
              <h2 className="font-serif text-3xl md:text-4xl text-charcoal leading-tight mt-2">
                {label.title}
              </h2>
              <div className="w-12 h-px bg-gold mt-4" />
            </div>
          ))}
        </div>

        <div className="h-[600vh]" />
      </main>
    </SmoothScroll>
  );
}
